$('#Parte1').on('hidden.bs.modal', function () {
    callPlayer('yt-player', 'stopVideo');
});