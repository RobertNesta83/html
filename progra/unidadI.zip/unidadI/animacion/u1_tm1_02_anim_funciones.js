(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"u1_tm1_02_anim_funciones_atlas_1", frames: [[0,0,1492,1011],[0,1013,1492,1011]]},
		{name:"u1_tm1_02_anim_funciones_atlas_2", frames: [[0,0,1492,1011],[0,1013,1492,1011]]},
		{name:"u1_tm1_02_anim_funciones_atlas_3", frames: [[0,0,1492,1011],[0,1013,1492,1011]]},
		{name:"u1_tm1_02_anim_funciones_atlas_4", frames: [[0,0,1492,1011],[542,1618,277,75],[0,1013,1048,603],[0,1926,417,67],[1494,0,334,719],[1050,1013,259,707],[1084,1728,873,25],[0,1618,540,306],[1494,721,540,306],[1311,1029,540,231],[1311,1262,540,231],[1311,1495,540,231],[542,1722,540,231]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_19 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["u1_tm1_02_anim_funciones_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.u1_tm1_fondo_06_vdependientesvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_19();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_fondo_05_vindependientesvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_18();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_fondo_04_rangosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_17();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_fondo_03_fxsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_16();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_fondo_02_contradominiosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_15();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_fondo_01_dominiosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_fondo_00_principalsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(-1,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,746,505.5);


(lib.u1_tm1_elemento_06_vdependientesvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuid_799e025e_2659_4bfd_9451_1ba4508ee743
	this.instance = new lib.CachedBmp_12();
	this.instance.setTransform(0,0,0.401,0.401);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,111.1,30.1);


(lib.u1_tm1_elemento_05_vindependientesvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuid_b020962c_d9ca_4f26_949d_0ef7a907a42a
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#18406F").ss(0.5).p("AgFACIgFgYIgDgHIgCgDIgDAAIgDAAIgDADIgFAHIgGgEQAFgIAGgFQAFgEAHAAIAFABIADACIADADIAEAOIABALIABAAIANgRQADgEAEgFQAEgDACAAQADgCAFAAQAEAAACACIgDAPIgGAAQgBgDgCAAIgCAAIgCABIgEAEIgSAVIAIAeIABAEIACACIADAAQABAAADgCQACgBAFgHIAGAEQgIAKgEADQgEADgHAAQgEAAgDgBQgDgBgBgDQgCgDgCgHIgCgRIgBAAIgOATQgFAGgCACIgGAEIgHABIgHgBIADgQIAHAAQAAAEADAAIACgBIAEgDg");
	this.shape.setTransform(55.5528,15.8524);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#18406F").s().p("AAIAqQgDAAgBgEQgCgDgCgGIgCgRIgBAAIgOASIgHAJIgGADIgHABIgHgBIADgPIAHAAQAAAAAAABQAAABABAAQAAABABAAQAAAAABAAIACAAIAEgDIAUgYIgFgZIgDgHIgCgDIgDAAIgDAAIgDADIgFAHIgGgEQAFgHAGgGQAFgDAHAAIAFAAIADACIADADIAEAPIABAKIABAAIANgRIAHgJIAGgDQADgCAFABQAEgBACACIgDAQIgGAAQAAgBgBgBQAAgBAAAAQgBgBAAAAQgBAAAAAAIgCAAIgCABIgEAEIgSAVIAIAfIABADIACACIADAAIAEgCIAHgIIAGAEQgIAKgEADQgEADgHAAQgEAAgDgBg");
	this.shape_1.setTransform(55.575,15.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00699B").ss(1.5).p("AoGiPIQNAAQAMAAAJAJQAJAJAAAMIAAEBIxJAAIAAkBQAAgMAJgJQAJgJAMAAg");
	this.shape_2.setTransform(55.6,15.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B2D2E1").s().p("AokCPIAAj/QABgNAIgJQAJgIANgBIQMAAQAMABAIAIQAKAJgBANIAAD/g");
	this.shape_3.setTransform(55.6,15.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,111.7,30.7);


(lib.u1_tm1_elemento_04_rangosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuid_a46a1a01_e4f5_4c28_9eaa_065f1237e6cc
	this.instance = new lib.CachedBmp_11();
	this.instance.setTransform(0,0,0.4063,0.4063);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,425.9,245);


(lib.u1_tm1_elemento_03_fxsvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuid_cbd9f0cc_df4c_4d61_a12b_18ae3e0a8bfe
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(0,0,0.2551,0.2551);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,106.4,17.1);


(lib.u1_tm1_elemento_02_contradominiosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuid_166c48d8_0bfd_4438_b64e_d804c4aadb3a
	this.instance = new lib.CachedBmp_9();
	this.instance.setTransform(0,0,0.3682,0.3682);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,123,264.8);


(lib.u1_tm1_elemento_01_dominiosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// uuid_b0745e58_86a1_41a9_a269_ae31d59050ef
	this.instance = new lib.CachedBmp_8();
	this.instance.setTransform(0,0,0.3745,0.3745);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,97,264.8);


(lib.Interpolación2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00CCFF").ss(2).p("ACmAAQAABEgxAxQgxAwhEAAQhDAAgxgwQgxgxAAhEQAAhDAxgxQAxgwBDAAQBEAAAxAwQAxAxAABDg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.4,-19.3,37,36.900000000000006);


(lib.Rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3FFFF").s().p("Eg4CAkNQgRAAgLgMQgMgMAAgRMAAAhHIQAAgQAMgMQALgMARAAMBwFAAAQAQAAAMAMQAMAMAAAQMAAABHIQAAARgMAMQgMAMgQAAg");
	this.shape.setTransform(362.675,231.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle, new cjs.Rectangle(0,0,725.4,463.3), null);


(lib.btn_cerrar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAnA8IgngnIgmAnQgGAFgFAAQgGAAgEgFQgFgEAAgGQAAgHAFgEIAngnIgngmQgFgFAAgGQAAgGAFgFQAEgEAGAAQAHAAAEAEIAmAoIAngoQAEgEAHAAQAGAAAEAEQAFAFAAAGQAAAGgFAFIgnAmIAnAnQAFAEAAAHQAAAGgFAEQgEAFgGAAQgFAAgGgFg");
	this.shape.setTransform(-0.025,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002949").s().p("AhPBuQgMAAgKgJQgIgIAAgNIAAifQAAgMAIgJQAKgJAMAAICfAAQANAAAIAJQAJAJAAAMIAACfQAAANgJAIQgIAJgNAAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0080B6").s().p("AhPBuQgMAAgKgJQgIgIAAgNIAAifQAAgNAIgIQAKgJAMAAICfAAQANAAAIAJQAJAIAAANIAACfQAAANgJAIQgIAJgNAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11,-11,22,22);


(lib.ventana_animada = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_24 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Capa_1
	this.instance = new lib.Rectangle();
	this.instance.setTransform(0.55,-1.45,0.0313,0.0313,0,0,0,362.7,231.7);
	this.instance.alpha = 0.1016;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,alpha:0.8984},24).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-362.1,-233.1,725.3,463.29999999999995);


(lib.mc_boton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Interpolación2("synched",0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.1994,scaleY:1.1994,alpha:0.3008},14).to({scaleX:1,scaleY:1,alpha:1},15).wait(1));

	// Capa_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00699B").ss(2).p("AB7AAQAAAygkAkQgkAlgzAAQgyAAgkglQgkgkAAgyQAAgyAkgkQAkgkAyAAQAzAAAkAkQAkAkAAAyg");
	this.shape.setTransform(-0.15,0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00699B").s().p("AhWBWQgjgjgBgzQABgxAjglQAlgjAxgBQAzABAjAjQAkAlAAAxQAAAzgkAjQgjAkgzAAQgxAAglgkg");
	this.shape_1.setTransform(-0.15,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(30));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.9,-22.8,45.7,45.6);


(lib.mc_06vdependiente = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Capa_1
	this.instance = new lib.u1_tm1_elemento_06_vdependientesvg("synched",0);
	this.instance.setTransform(0.05,0,1,1,0,0,0,55.6,15.1);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:54.9,regY:14.6,scaleX:1.2467,scaleY:1.2467,x:-0.15,y:-0.15,alpha:1},19).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.6,-18.7,138.5,37.9);


(lib.mc_04rango = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Capa_1
	this.instance = new lib.u1_tm1_elemento_04_rangosvg("synched",0);
	this.instance.setTransform(-0.55,0.05,1,1,0,0,0,212.8,122.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:122.4,scaleX:1.2305,scaleY:1.2305,x:-50.5,y:-0.05,alpha:1},19).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-312.3,-150.6,524.8,301.5);


(lib.mc_03fx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Capa_1
	this.instance = new lib.u1_tm1_elemento_03_fxsvg("synched",0);
	this.instance.setTransform(0,-0.05,1,1,0,0,0,45.2,8.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:45.1,regY:8.4,scaleX:1.96,scaleY:1.96,x:-0.15,y:-0.25,alpha:1},19).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.5,-16.7,208.5,33.5);


(lib.mc_02contradominio = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Capa_1
	this.instance = new lib.u1_tm1_elemento_02_contradominiosvg("synched",0);
	this.instance.setTransform(0.05,-0.55,1,1,0,0,0,61.6,132.3);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:61.5,scaleX:1.3578,scaleY:1.3578,x:-0.05,alpha:1},19).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.5,-180.2,167,359.5);


(lib.mc_01dominio = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Capa_1
	this.instance = new lib.u1_tm1_elemento_01_dominiosvg("synched",0);
	this.instance.setTransform(0,-0.55,1,1,0,0,0,48.5,132.3);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.335,scaleY:1.335,x:0.05,alpha:1},19).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.7,-177.1,129.5,353.5);


(lib.btn_01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Btns
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhkZoQnzgXheudQg4olBardQAJg+AlgtQAmguA5gSQC4gxBuA3QBGAjAjBFQAiBDgJBMQhUKJgVHdQgkM0CqATQATgDAigaQBDg1BJhvQDqlmDKs0QAFgcAOgbQAeg2AzAEQAsAHAGA3QADAcgGAbQg8GJiEGFQkBL4laAAIgQAAgAl5u1Qg5gVguhEQhdiJA3jvQAPg8Ang7QBOh0B5ALQCNARAtCbQArCThACwQg2CShiArQgmARghAAQgdAAgZgMg");
	this.shape.setTransform(1.0107,0.0326,0.0478,0.0478);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},3).wait(1));

	// Capa_1
	this.instance = new lib.mc_boton();
	this.instance.setTransform(-1,-0.9,1,1,0,0,0,-1,-0.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00699B").ss(2).p("ACmAAQAABEgxAxQgxAwhEAAQhDAAgxgwQgxgxAAhEQAAhDAxgxQAxgwBDAAQBEAAAxAwQAxAxAABDgAB5ADQAAAygkAkQgkAkgyAAQgyAAgkgkQgkgkAAgyQAAgyAkgkQAkgkAyAAQAyAAAkAkQAkAkAAAyg");
	this.shape_1.setTransform(0,0.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00699B").s().p("AhWBWQgjgjgBgzQABgxAjglQAlgjAxgBQAzABAjAjQAkAlAAAxQAAAzgkAjQgjAkgzAAQgxAAglgkg");
	this.shape_2.setTransform(-0.15,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#66CCFF").s().p("AhWBWQgjgjgBgzQABgxAjglQAlgjAxgBQAzABAjAjQAkAlAAAxQAAAzgkAjQgjAkgzAAQgxAAglgkg");
	this.shape_3.setTransform(-0.15,0.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#00699B").ss(2).p("AB7AAQAAAygkAkQgkAlgzAAQgyAAgkglQgkgkAAgyQAAgyAkgkQAkgkAyAAQAzAAAkAkQAkAkAAAyg");
	this.shape_4.setTransform(-0.15,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape_3},{t:this.shape_1}]},1).to({state:[{t:this.shape_3},{t:this.shape_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.4,-19.3,37,36.900000000000006);


(lib._05_vindependiente = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Capa_1
	this.instance = new lib.u1_tm1_elemento_05_vindependientesvg("synched",0);
	this.instance.setTransform(0,0,1,1,0,0,0,55.6,15.1);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.2552,scaleY:1.2552,x:0.05,alpha:1},19).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.8,-19,139.7,38);


// stage content:
(lib.u1_tm1_02_anim_funciones = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,1,2,3,4,5,6];
	// timeline functions:
	this.frame_0 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_01.addEventListener("click", fl_ClickToGoToAndStopAtFrame_10.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_10()
		{
			this.gotoAndStop(1);
		}
		
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_02.addEventListener("click", fl_ClickToGoToAndStopAtFrame_11.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_11()
		{
			this.gotoAndStop(2);
		}
		
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_03.addEventListener("click", fl_ClickToGoToAndStopAtFrame_12.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_12()
		{
			this.gotoAndStop(3);
		}
		
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_04.addEventListener("click", fl_ClickToGoToAndStopAtFrame_13.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_13()
		{
			this.gotoAndStop(4);
		}
		
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_05.addEventListener("click", fl_ClickToGoToAndStopAtFrame_14.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_14()
		{
			this.gotoAndStop(5);
		}
		
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_06.addEventListener("click", fl_ClickToGoToAndStopAtFrame_15.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_15()
		{
			this.gotoAndStop(6);
		}
	}
	this.frame_1 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_cerrar01.addEventListener("click", fl_ClickToGoToAndStopAtFrame_16.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_16()
		{
			this.gotoAndStop(0);
		}
	}
	this.frame_2 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_cerrar02.addEventListener("click", fl_ClickToGoToAndStopAtFrame_17.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_17()
		{
			this.gotoAndStop(0);
		}
	}
	this.frame_3 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_cerrar03.addEventListener("click", fl_ClickToGoToAndStopAtFrame_18.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_18()
		{
			this.gotoAndStop(0);
		}
	}
	this.frame_4 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_cerrar04.addEventListener("click", fl_ClickToGoToAndStopAtFrame_19.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_19()
		{
			this.gotoAndStop(0);
		}
	}
	this.frame_5 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_cerrar05.addEventListener("click", fl_ClickToGoToAndStopAtFrame_20.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_20()
		{
			this.gotoAndStop(0);
		}
	}
	this.frame_6 = function() {
		/* Detener en este fotograma
		La línea de tiempo se detendrá/pausará en el fotograma en el que se inserte este código.
		También se puede utilizar para detener/pausar la línea de tiempo de clips de película.
		*/
		
		this.stop();
		
		/* Hacer clic para ir al fotograma y detener
		Al hacer clic en la instancia del símbolo especificado, la cabeza lectora se mueve hasta el fotograma especificado en la línea de tiempo y detiene la película.
		Se puede utilizar en la línea de tiempo principal o en líneas de tiempo de clips de película.
		
		Instrucciones:
		1. Reemplace el número 5 del siguiente código por el número de fotograma hasta el que quiere que se mueva la cabeza lectora cuando se haga clic en la instancia del símbolo.
		2.Los números de fotograma en EaselJS empiezan con 0 en vez de 1
		*/
		
		
		this.btn_cerrar01.addEventListener("click", fl_ClickToGoToAndStopAtFrame_21.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_21()
		{
			this.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Botones
	this.btn_04 = new lib.btn_01();
	this.btn_04.name = "btn_04";
	this.btn_04.setTransform(709.4,303.75,1,1,0,0,0,-1,-0.9);
	new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_06 = new lib.btn_01();
	this.btn_06.name = "btn_06";
	this.btn_06.setTransform(229.75,208.35,1,1,0,0,0,-1,-0.9);
	new cjs.ButtonHelper(this.btn_06, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_05 = new lib.btn_01();
	this.btn_05.name = "btn_05";
	this.btn_05.setTransform(112.75,208.35,1,1,0,0,0,-1,-0.9);
	new cjs.ButtonHelper(this.btn_05, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_03 = new lib.btn_01();
	this.btn_03.name = "btn_03";
	this.btn_03.setTransform(201.9,148.6,1,1,0,0,0,-1,-0.9);
	new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_02 = new lib.btn_01();
	this.btn_02.name = "btn_02";
	this.btn_02.setTransform(466.15,377.05,1,1,0,0,0,-1,-0.9);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_01 = new lib.btn_01();
	this.btn_01.name = "btn_01";
	this.btn_01.setTransform(292.9,377.05,1,1,0,0,0,-1,-0.9);
	new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_cerrar01 = new lib.btn_cerrar();
	this.btn_cerrar01.name = "btn_cerrar01";
	this.btn_cerrar01.setTransform(719.8,365.5);
	new cjs.ButtonHelper(this.btn_cerrar01, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.btn_cerrar02 = new lib.btn_cerrar();
	this.btn_cerrar02.name = "btn_cerrar02";
	this.btn_cerrar02.setTransform(399.1,58.6);
	new cjs.ButtonHelper(this.btn_cerrar02, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.btn_cerrar03 = new lib.btn_cerrar();
	this.btn_cerrar03.name = "btn_cerrar03";
	this.btn_cerrar03.setTransform(539.4,214.85);
	new cjs.ButtonHelper(this.btn_cerrar03, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.btn_cerrar04 = new lib.btn_cerrar();
	this.btn_cerrar04.name = "btn_cerrar04";
	this.btn_cerrar04.setTransform(726.25,378.35);
	new cjs.ButtonHelper(this.btn_cerrar04, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.btn_cerrar05 = new lib.btn_cerrar();
	this.btn_cerrar05.name = "btn_cerrar05";
	this.btn_cerrar05.setTransform(471.2,125.4);
	new cjs.ButtonHelper(this.btn_cerrar05, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_01},{t:this.btn_02},{t:this.btn_03},{t:this.btn_05},{t:this.btn_06},{t:this.btn_04}]}).to({state:[{t:this.btn_cerrar01,p:{x:719.8,y:365.5}}]},1).to({state:[{t:this.btn_cerrar02}]},1).to({state:[{t:this.btn_cerrar03}]},1).to({state:[{t:this.btn_cerrar04}]},1).to({state:[{t:this.btn_cerrar05}]},1).to({state:[{t:this.btn_cerrar01,p:{x:577.45,y:117.35}}]},1).wait(1));

	// tools
	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(450,365.3,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_2();
	this.instance_1.setTransform(130.15,57.25,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_3();
	this.instance_2.setTransform(270.45,213.25,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4();
	this.instance_3.setTransform(457.05,376.6,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_5();
	this.instance_4.setTransform(202.3,123.7,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_6();
	this.instance_5.setTransform(308.5,115.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	// elementos
	this.mc_01dominio = new lib.mc_01dominio();
	this.mc_01dominio.name = "mc_01dominio";
	this.mc_01dominio.setTransform(349.6,277.2);

	this.mc_02dominio = new lib.mc_02contradominio();
	this.mc_02dominio.name = "mc_02dominio";
	this.mc_02dominio.setTransform(522.4,276.8);

	this.instance_6 = new lib.mc_03fx();
	this.instance_6.setTransform(138.4,165.6);

	this.instance_7 = new lib.mc_04rango();
	this.instance_7.setTransform(513.1,266.4,1,1,0,0,0,-0.5,0);

	this.instance_8 = new lib._05_vindependiente();
	this.instance_8.setTransform(80.8,196.8);

	this.instance_9 = new lib.mc_06vdependiente();
	this.instance_9.setTransform(196,196.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.mc_01dominio}]},1).to({state:[{t:this.mc_02dominio}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).wait(1));

	// ventana
	this.instance_10 = new lib.CachedBmp_7();
	this.instance_10.setTransform(154.5,487.1,0.5,0.5);

	this.instance_11 = new lib.ventana_animada();
	this.instance_11.setTransform(372.5,261);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10}]}).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_11}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1).to({_off:false},0).wait(6));

	// Fondos
	this.instance_12 = new lib.u1_tm1_fondo_00_principalsvg("synched",0);
	this.instance_12.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.instance_13 = new lib.u1_tm1_fondo_01_dominiosvg("synched",0);
	this.instance_13.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.instance_14 = new lib.u1_tm1_fondo_02_contradominiosvg("synched",0);
	this.instance_14.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.instance_15 = new lib.u1_tm1_fondo_03_fxsvg("synched",0);
	this.instance_15.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.instance_16 = new lib.u1_tm1_fondo_04_rangosvg("synched",0);
	this.instance_16.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.instance_17 = new lib.u1_tm1_fondo_05_vindependientesvg("synched",0);
	this.instance_17.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.instance_18 = new lib.u1_tm1_fondo_06_vdependientesvg("synched",0);
	this.instance_18.setTransform(372,252.7,1,1,0,0,0,372,252.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(371.5,266,373.5,239.5);
// library properties:
lib.properties = {
	id: 'E5DD6F27E1E3A84BAD206832844607EC',
	width: 745,
	height: 532,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/u1_tm1_02_anim_funciones_atlas_1.png?1694630300016", id:"u1_tm1_02_anim_funciones_atlas_1"},
		{src:"images/u1_tm1_02_anim_funciones_atlas_2.png?1694630300016", id:"u1_tm1_02_anim_funciones_atlas_2"},
		{src:"images/u1_tm1_02_anim_funciones_atlas_3.png?1694630300016", id:"u1_tm1_02_anim_funciones_atlas_3"},
		{src:"images/u1_tm1_02_anim_funciones_atlas_4.png?1694630300016", id:"u1_tm1_02_anim_funciones_atlas_4"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['E5DD6F27E1E3A84BAD206832844607EC'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;